<?php $__env->startSection('page-small-title','Personnel'); ?>
<?php $__env->startSection('page-title','View Personnel'); ?>
<?php $__env->startPrepend('page-css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.css">
<?php $__env->stopPrepend(); ?>
<?php $__env->startSection('content'); ?>
<div class="card" >
    <div class="card-body">
      <div class="row float-left col-lg-7">
        <div class="col-lg-7">
          <span>Filter by Province</span>
          <select name="cities" id="province_filter" class="form-control">
            <option value="all">Show All</option>
            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($province->code); ?>"> <?php echo e($province->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>


      </div>
      
      <div class="clearfix mb-2"></div>
      <table class="table table-bordered " id="persons-table" style="width:100%;">
        <thead>
          <tr>
            <td scope="col" class="font-weight-bold">ID</td>
            <td scope="col" class="font-weight-bold">Firstname</td>
            <td scope="col" class="font-weight-bold">Middlename</td>
            <td scope="col" class="font-weight-bold">Lastname</td>
            <td scope="col" class="font-weight-bold">Province</td>
            <td scope="col" class="font-weight-bold">City</td>
            <td scope="col" class="font-weight-bold">Barangay</td>
            <td scope="col" class="font-weight-bold">Option</td>
          </tr>
        </thead>
        <tbody>
        </tbody>
      </table>
  </div>
</div>
  <?php $__env->startPush('page-scripts'); ?>
  <script>
    $.ajaxSetup({
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
  });
  </script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script>
    let QUERY_STRING = 'all';

    if(localStorage.getItem('FILTER_SELECT') == null) {
      QUERY_STRING = 'all';
    } else {
      QUERY_STRING = localStorage.getItem('FILTER_SELECT');
      $('#province_filter').val(QUERY_STRING);
    }

    let person_table =  $('#persons-table').DataTable({
            serverSide: true,
            ajax: `/admin/persons/list/${QUERY_STRING}`,
            columns: [
                { name: 'person_id' },
                { name: 'firstname' },
                { name: 'middlename' },
                { name: 'lastname' },
                { name: 'province.name' },
                { name: 'city.name' },
                { name: 'barangay.name' },
                { name: 'admin_action' , searchable : false, orderable : false, },
            ],
        });
  </script>

   <script>
      $('#province_filter').change(function (e) {
          QUERY_STRING = $(this).val();
          localStorage.setItem('FILTER_SELECT', QUERY_STRING);
          person_table.ajax.url(`/admin/persons/list/${QUERY_STRING}`).load();
      });
    </script>
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\capitol_app\resources\views/admin/personnel/index.blade.php ENDPATH**/ ?>