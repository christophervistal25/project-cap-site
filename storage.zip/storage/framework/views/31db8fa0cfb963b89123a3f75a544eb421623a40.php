<?php if($errors->any()): ?>
    <div class="bg-danger text-white">
        <div class="p-3">
                <?php $__currentLoopData = array_unique($errors->all()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>




<?php /**PATH C:\xampp\htdocs\capitol_app\resources\views/templates/error.blade.php ENDPATH**/ ?>