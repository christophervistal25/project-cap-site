<?php $__env->startSection('page-small-title','Personnel'); ?>
<?php $__env->startSection('page-title','Add New Personnel'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-2">
    <?php if(Session::has('success')): ?>
    <div class="card bg-success text-white shadow">
        <div class="card-body">Successfully add new personnel.</div>
    </div>
    <?php endif; ?>
    
</div>
<section id="basic-alerts">
    <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('personnel.store')); ?>" >
    <?php echo csrf_field(); ?>
  <div class="row match-height">
            <div class="col-xl-12 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Personnel Information</h4>
                        <a class="heading-elements-toggle">
                            <i class="la la-ellipsis-v font-medium-3"></i>
                        </a>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <div class="row">
                                    <div class="form-group  col-lg-3">
                                        <label for="firstname">Firstname <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php echo e($errors->has('firstname')  ? 'is-invalid' : ''); ?>" id="firstname" name="firstname" placeholder="Enter Firstname" value="<?php echo e(old('firstname')); ?>">
                                        <?php if($errors->has('firstname')): ?>
                                            <small  class="form-text text-danger">
                                                <?php echo e($errors->first('firstname')); ?> </small>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group col-lg-3 ">
                                            <label for="middlename">Middlename <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control <?php echo e($errors->has('middlename')  ? 'is-invalid' : ''); ?> " id="middlename" name="middlename" placeholder="Enter Middlename" value="<?php echo e(old('middlename')); ?>">
                                            <?php if($errors->has('middlename')): ?>
                                            <small  class="form-text text-danger"><?php echo e($errors->first('middlename')); ?> </small>
                                            <?php endif; ?>
                                    </div>

                                    <div class="form-group col-lg-3">
                                        <label for="lastname">Lastname <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php echo e($errors->has('lastname')  ? 'is-invalid' : ''); ?>" id="lastname" name="lastname" placeholder="Enter Lastname" value="<?php echo e(old('lastname')); ?>">

                                        <?php if($errors->has('lastname')): ?>
                                            <small  class="form-text text-danger">
                                            <?php echo e($errors->first('lastname')); ?> </small>
                                        <?php endif; ?>
                                    </div>

                                    <div class="form-group col-lg-3">
                                        <label for="suffix">Suffix <span class="text-danger">*</span></label>
                                        <input type="text" maxlength="3" class="form-control <?php echo e($errors->has('suffix')  ? 'is-invalid' : ''); ?>" id="suffix" name="suffix" placeholder="e.g Jr." value="<?php echo e(old('suffix')); ?>">
                                        <?php if($errors->has('suffix')): ?>
                                            <small  class="form-text text-danger">
                                            <?php echo e($errors->first('suffix')); ?> </small>
                                        <?php endif; ?>
                                    </div>
                            </div>







                            

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <label for="date_of_birth">Date of birth <span class="text-danger">*</span></label>
                                        <input type="date" class="form-control  <?php echo e($errors->has('date_of_birth')  ? 'is-invalid' : ''); ?>" id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>">
                                        <?php if($errors->has('date_of_birth')): ?>
                                            <small  class="form-text text-danger">
                                            <?php echo e($errors->first('date_of_birth')); ?> </small>
                                        <?php endif; ?>
                                    </div>


                                </div>
                            </div>

                            


                            <div class="form-group">
                                    <label for="province">Province<span class="text-danger">*</span></label>
                                    <select name="province" id="province" class="form-control <?php echo e($errors->has('province')  ? 'is-invalid' : ''); ?>">
                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(old('province')): ?>
                                                    <option <?php echo e(old('province') == $province->code ? 'selected' : ''); ?> value="<?php echo e($province->code); ?>"> <?php echo e($province->name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($province->code); ?>"> <?php echo e($province->name); ?></option>
                                                <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                    </select>
                                    <?php if($errors->has('province')): ?>
                                        <small  class="form-text text-danger">
                                        <?php echo e($errors->first('province')); ?> </small>
                                    <?php endif; ?>
                             </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="city">City <span class="text-danger">*</span></label>
                                        <select name="city" id="cities" class="form-control <?php echo e($errors->has('city')  ? 'is-invalid' : ''); ?>">
                                            <option value="" disabled>Select province</option>
                                            
                                        </select>
                                        <?php if($errors->has('city')): ?>
                                        <small  class="form-text text-danger">
                                        <?php echo e($errors->first('city')); ?> </small>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="barangay">Barangay<span class="text-danger"> *</span></label>
                                        <select name="barangay" id="barangay" class="form-control <?php echo e($errors->has('barangay')  ? 'is-invalid' : ''); ?>">
                                            <option value="" disabled>Select City</option>
                                            
                                        </select>
                                        <?php if($errors->has('barangay')): ?>
                                        <small  class="form-text text-danger">
                                        <?php echo e($errors->first('barangay')); ?> </small>
                                        <?php endif; ?>
                                    </div>
                                    </div>
                                </div>

                            <div class="form-group">
                                    <label for="puroksub">Temporary Address<span class="text-danger">*</span></label>
                                     <textarea name="temporary_address" id="temporary_address" class="form-control"><?php echo e(old('temporary_address')); ?></textarea>
                                    <?php if($errors->has('temporary_address')): ?>
                                        <small  class="form-text text-danger">
                                            <?php echo e($errors->first('temporary_address')); ?> 
                                        </small>
                                    <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="address">Permanent Address <span class="text-danger">*</span></label>
                                <textarea name="address" id="address" class="form-control <?php echo e($errors->has('address')  ? 'is-invalid' : ''); ?>" rows="3"><?php echo e(old('address')); ?></textarea>
                                <?php if($errors->has('address')): ?>
                                    <small  class="form-text text-danger">
                                    <?php echo e($errors->first('address')); ?> </small>
                                <?php endif; ?>
                            </div>

                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="gender">Sex <span class="text-danger">*</span></label>
                                        <select name="gender" id="gender" class="form-control <?php echo e($errors->has('gender')  ? 'is-invalid' : ''); ?>">
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="status">Status <span class="text-danger">*</span></label>
                                            <select name="status" id="status" class="form-control <?php echo e($errors->has('status')  ? 'is-invalid' : ''); ?>">
                                                <?php $__currentLoopData = $civil_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value=<?php echo e($status); ?>><?php echo e($status); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"><?php echo e($errors->first('status')); ?></div>
                                </div>
                                </div>
                            </div>
                            
                            

                            

                            <div class="row">
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" class="form-control <?php echo e($errors->has('email')  ? 'is-invalid' : ''); ?>" id="email" name="email" placeholder="Optional" value="<?php echo e(old('email')); ?>">
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="phone_number">Cellphone Number <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control <?php echo e($errors->has('phone_number')  ? 'is-invalid' : ''); ?>" id="phone_number" name="phone_number" placeholder="" value="<?php echo e(old('phone_number')); ?>">
                                    </div>
                                </div>

                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label for="landline_number">Landline Number</label>
                                        <input type="text" class="form-control <?php echo e($errors->has('landline_number')  ? 'is-invalid' : ''); ?>" id="landline_number" name="landline_number" placeholder="" value="<?php echo e(old('landline_number')); ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="">Image <span class="text-danger">*</span></label>
                                <div class="custom-file">
                                    <input type="file" name="image" class="custom-file-input <?php echo e($errors->has('image')  ? 'is-invalid' : ''); ?>" id="imageFile" >
                                    <label class="custom-file-label" for="imageFile">Choose file...</label>
                                    <div class="invalid-feedback"><?php echo e($errors->first('image')); ?></div>
                                </div>
                            </div>

                            <div class="float-right">
                                <button type="submit" class="btn btn-primary">Add New Personnel</button>
                                <?php if(Session::has('success')): ?>
                                    <a href="<?php echo e(route('admin.print.qr', Session::get('success'))); ?>" class="btn btn-success">Generate</a>
                                <?php endif; ?>
                            </div>

                            <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>
</section>
<?php $__env->startPush('page-scripts'); ?>

<script>
    $(document).ready(function () {
        
        $('#province').change(function (e) {
            $.ajax({
                url : `/api/province/municipal/${e.target.value}`,
                success : function (response) {
                    // Clear all option of cities select element
                    $('#cities').find('option').remove();
                    response.municipals.forEach((municipal) => $('#cities').append(`<option value="${municipal.code}">${municipal.name}</option>`));
                },
            });
        });

        $('#cities').change(function (e) {
            console.log(e.target.value);
            $.ajax({
                url : `/api/province/barangay/${e.target.value}`,
                success : function (response) {
                    // Clear all option of barangay select element
                    $('#barangay').find('option').remove();
                    response.barangays.forEach((barangay) => $('#barangay').append(`<option value="${barangay.code}">${barangay.name}</option>`));
                },
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\capitol_app\resources\views/admin/personnel/create.blade.php ENDPATH**/ ?>