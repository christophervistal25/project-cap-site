<?php $__env->startSection('page-small-title','Personnel'); ?>
<?php $__env->startSection('page-title','Add New Establishment'); ?>
<?php $__env->startSection('content'); ?>

<section id="basic-alerts">
<form action="<?php echo e(route('establishment.store')); ?>" method="POST">
   <?php echo csrf_field(); ?>
  <div class="row match-height">
      <div class="col-xl-2 col-lg-12"></div>
            <div class="col-xl-8 col-lg-12">
                <div class="mb-2">
                    <?php if(Session::has('success')): ?>
                    <div class="card bg-success text-white shadow">
                        <div class="card-body">Successfully add new establishment.</div>
                    </div>
                    <?php endif; ?>
                    
                </div>
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Establishment Information</h4>
                        <a class="heading-elements-toggle">
                            <i class="la la-ellipsis-v font-medium-3"></i>
                        </a>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="office_store_name">Establishment/Office/Store Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php echo e($errors->has('office_store_name') ? 'is-invalid' : ''); ?>" id="office_store_name" name="office_store_name" placeholder="Enter Establishment/Office/Store Name" >
                                <?php if($errors->has('office_store_name')): ?>
                                    <small  class="form-text text-danger">
                                        <?php echo e($errors->first('office_store_name')); ?> </small>
                                <?php endif; ?>
                            </div>

                                <div class="form-group mt-1">
                                    <label for="establishment_type">Establishment Type <span class="text-danger">*</span></label>
                                    <select name="type" id="establishment_type" class="form-control <?php echo e($errors->has('type')  ? 'is-invalid' : ''); ?>">
                                        <option  selected disabled>Please Select Establishment Type</option>
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($type); ?>"> <?php echo e($type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php if($errors->has('type')): ?>
                                    <small class="form-text text-danger">
                                        <?php echo e($errors->first('type')); ?> </small>
                                    <?php endif; ?>
                                </div>
                            <div class="form-group mt-1">
                                <label for="address">Address<span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" id="address" name="address" placeholder="Enter Address">
                                <?php if($errors->has('address')): ?>
                                <small class="form-text text-danger">
                                    <?php echo e($errors->first('address')); ?> </small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="contact_number">Contact Number <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php echo e($errors->has('contact_number') ? 'is-invalid' : ''); ?>" id="contact_number" name="contact_number" placeholder="Enter Contact Number">
                                <?php if($errors->has('contact_number')): ?>
                                <small class="form-text text-danger">
                                    <?php echo e($errors->first('contact_number')); ?> </small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="geo_tag_location">Geo Tag Location <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php echo e($errors->has('geo_tag_location') ? 'is-invalid' : ''); ?>" id="geo_tag_location" name="geo_tag_location" placeholder="Enter Geo Tag Location">
                                <?php if($errors->has('geo_tag_location')): ?>
                                <small class="form-text text-danger">
                                    <?php echo e($errors->first('geo_tag_location')); ?> </small>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="province">Province <span class="text-danger">*</span></label>
                                <select name="province" id="province" class="form-control">
                                    <option>Surigao del Sur</option>
                                </select>
                                <?php if($errors->has('province')): ?>
                                <small class="form-text text-danger">
                                    <?php echo e($errors->first('province')); ?> </small>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="city">City <span class="text-danger">*</span></label>
                                        <select name="city" id="cities" class="form-control <?php echo e($errors->has('city')  ? 'is-invalid' : ''); ?>">

                                            <option  selected disabled>Please Select City</option>
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($city->zip_code); ?>"> <?php echo e($city->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('city')): ?>
                                        <small class="form-text text-danger">
                                            <?php echo e($errors->first('city')); ?> </small>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="barangay">Barangay <span class="text-danger">*</span></label>
                                        <select name="barangay" id="barangay" class="form-control <?php echo e($errors->has('barangay')  ? 'is-invalid' : ''); ?>">
                                            <option  selected disabled>Please Select Barangay</option>
                                        </select>
                                        <?php if($errors->has('barangay')): ?>
                                        <small class="form-text text-danger">
                                            <?php echo e($errors->first('barangay')); ?> </small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="float-right">
                                <button type="submit" class="btn btn-primary">Add New Establishment</button>

                                <?php if(Session::has('success')): ?>
                                    <a href="" class="btn btn-success">Generate</a>
                                <?php endif; ?>
                            </div>

                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-2 col-lg-12"></div>
    </div>
    </form>
</section>
<?php $__env->startPush('page-scripts'); ?>
<script>
    $(document).ready(function () {
        let barangayOptionAll = [<?php $__currentLoopData = $barangay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>{city_zip_code:'<?php echo e($barangay->city_zip_code); ?>', name:'<?php echo e($barangay->name); ?>'}, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>];
        $('#cities').change(function (e) {
            let cityZipCode = e.target.value;
            //filter all barangay data//
            let barangayfilter = barangayOptionAll.filter(function(barangay){
                return barangay.city_zip_code == cityZipCode;
            });
            //Remove all option in #barangay//
            function removeOptionsBarangay(selectBarangay) {
                var ii, L = selectBarangay.options.length - 1;
                for(ii = L; ii >= 0; ii--) {
                    selectBarangay.remove(ii);
                }
            }
            removeOptionsBarangay(document.getElementById('barangay'));
            //add barangay data based in what you select in #cities//
            var i, length_barangay = barangayfilter.length;
            for (i = 0; i < length_barangay; i++) {
                var barangayfilter_final = barangayfilter[i];
                $('#barangay').append('<option data-zip-code="' + barangayfilter_final.city_zip_code + '">' + barangayfilter_final.name + '</option>');
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\capitol_app\resources\views/admin/establishment/create.blade.php ENDPATH**/ ?>