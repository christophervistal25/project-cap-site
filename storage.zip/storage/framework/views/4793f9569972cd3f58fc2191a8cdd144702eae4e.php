<?php if(Session::has('success')): ?>
    <div class="card bg-success text-white shadow">
        <div class="card-body">
             <?php echo e(Session::get('success')); ?>

        </div>
    </div>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\capitol_app\resources\views/templates/success.blade.php ENDPATH**/ ?>