<table class="table table-bordered" id="persons-table" style="width:100%;">
    <thead>
      <tr>
        <td scope="col" class="font-weight-bold">Firstname</td>
        <td scope="col" class="font-weight-bold">Middlename</td>
        <td scope="col" class="font-weight-bold">Lastname</td>
        <td scope="col" class="font-weight-bold">Suffix</td>
        <td scope="col" class="font-weight-bold">Date of birth</td>
        <td scope="col" class="font-weight-bold">Rapid test issued</td>
      </tr>
    </thead>
    <tbody>
    </tbody>
  </table>