<div class="text-center">
    <a class="btn btn-warning btn-icon  btn-sm" href="{{ route('track.show', $person) }}" target="_blank"><i class="la la-map"></i> TRACK</a>
</div>
