<a href="{{  route('establishment.edit', $establishment->id) }}" class="btn btn-icon btn-sm btn-success">
    <i class="la la-edit"></i>
</a>