@component('mail::message')
# SDSSU University Online Reporting System

{{ $messages }}

Thanks,<br>
Administrator
@endcomponent