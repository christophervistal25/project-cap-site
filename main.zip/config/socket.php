<?php

return [
	// 'https://university-quarter-socket.herokuapp.com/'
	'base_url' => 'https://university-quarter-socket.herokuapp.com/',
    // 'base_url' => 'http://192.168.1.9:3030',
];
