<?php

return [


    'token' => 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJhZG1pbiIsImlhdCI6MTU4MzYwMjg2MiwiZXhwIjo0MTAyNDQ0ODAwLCJ1aWQiOjc3ODc5LCJyb2xlcyI6WyJST0xFX1VTRVIiXX0.jVkkS-ICVbpBjSFiLTswN2OuZO7h7k9-6zM0yKxjbrs',

    'deviceId' => '2',

];
