<div class="text-center">
    <a class="text-sm btn btn-sm btn-info  btn-icon btn-info hide_btna" href="<?php echo e(route('personnel.logs', $person->id)); ?>" target="_blank" title="View Generated QR Code"  style="color:white;"> <i class="la la-history"></i></a>
    <a class="btn btn-success btn-icon  btn-sm" href="<?php echo e(route('admin.print.qr', $person->id)); ?>" target="_blank"><i class="la la-print"></i></a>
</div>
<?php /**PATH C:\xampp\htdocs\capitol_app\resources\views/admin/personnel/includes/index_action.blade.php ENDPATH**/ ?>