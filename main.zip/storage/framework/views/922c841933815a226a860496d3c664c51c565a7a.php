<?php $__env->startSection('page-small-title','Personnel'); ?>
<?php $__env->startSection('page-title','View Establishment'); ?>
<?php $__env->startPrepend('page-css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.css">
<?php $__env->stopPrepend(); ?>
<?php $__env->startSection('content'); ?>
<div class="card" >
    <div class="card-body">
      <div class="row float-left col-lg-7">
        <div class="col-lg-7">
          
        </div>


      </div>
      <div class="clearfix mb-2"></div>
      <table class="table table-bordered" id="establishments-table" style="width:100%;">
        <thead>
          <tr>
            <td scope="col" class="text-center font-weight-bold">ID</td>
            <td scope="col" class="text-center font-weight-bold">Establishment/Office/Store Name</td>
            <td scope="col" class="text-center font-weight-bold">Address Located</td>
            <td scope="col" class="text-center font-weight-bold">Contact Number</td>
            <td scope="col" class="text-center font-weight-bold">Geo Tag Location</td>
            <td scope="col" class="text-center font-weight-bold">Date/Time register</td>
            <td scope="col" class="text-center font-weight-bold">Option</td>
          </tr>
        </thead>
        <tbody class="text-center">
          
        </tbody>
      </table>
  </div>
</div>
  <?php $__env->startPush('page-scripts'); ?>
  <script>
    $.ajaxSetup({
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
  });
  </script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script>
    // let QUERY_STRING = 'all';

    // if(localStorage.getItem('FILTER_SELECT') == null) {
    //   QUERY_STRING = 'all';
    // } else {
    //   QUERY_STRING = localStorage.getItem('FILTER_SELECT');
    //   $('#city_filter').val(QUERY_STRING);
    // }

    let person_table =  $('#establishments-table').DataTable({
            serverSide: true,
            ajax: `/admin/establishment/list/`,
            columns: [
                { name: 'id' },
                { name: 'name' },
                { name: 'address' },
                { name: 'contact_no' },
                { name: 'geo_tag_location' },
                { name: 'created_at' },
                { name: 'admin_action' , searchable : false, orderable : false, },
            ],
        });
  </script>

   
  <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\capitol_app\resources\views/admin/establishment/index.blade.php ENDPATH**/ ?>