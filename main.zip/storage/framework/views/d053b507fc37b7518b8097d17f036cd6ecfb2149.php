<?php $__env->startPrepend('page-css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.css">
<?php $__env->stopPrepend(); ?>
<?php $__env->startSection('page-small-title','Personnel'); ?>
<?php $__env->startSection('page-title',  $person->firstname . ' ' . $person->middlename[0] . '. ' . $person->lastname . ' ' . $person->suffix . ' Logs'); ?>
<?php $__env->startSection('content'); ?>
<section id="basic-alerts">
  <div class="row match-height">
      <div class="col-xl-12 col-lg-12">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active text-white" id="information-tab" data-toggle="tab" href="#information" role="tab" aria-controls="information" aria-selected="true">Information</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" id="history-tab" data-toggle="tab" href="#history" role="tab" aria-controls="history" aria-selected="false">History</a>
            </li>
          </ul>
          <div class="tab-content">
            <div class="tab-pane fade show active" id="information" role="tabpanel" aria-labelledby="information-tab">
                <div class="col-xl-12 col-lg-12 mt-2">
                <?php echo $__env->make('templates.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('personnel.logs.update', $person->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Personnel Information</h4>
                            <a class="heading-elements-toggle">
                                <i class="la la-ellipsis-v font-medium-3"></i>
                            </a>
                        </div>
                        <div class="card-content collapse show">
                            <div class="card-body">
                                <div class="row">
                                        <div class="form-group  col-lg-3">
                                            <label for="firstname">Firstname <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control <?php echo e($errors->has('firstname')  ? 'is-invalid' : ''); ?>" id="firstname" name="firstname" placeholder="Enter Firstname" value="<?php echo e(old('firstname') ?? $person->firstname); ?>">
                                            <?php if($errors->has('firstname')): ?>
                                                <small  class="form-text text-danger">
                                                    <?php echo e($errors->first('firstname')); ?> </small>
                                            <?php endif; ?>
                                        </div>
    
                                        <div class="form-group col-lg-3 ">
                                                <label for="middlename">Middlename <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control <?php echo e($errors->has('middlename')  ? 'is-invalid' : ''); ?> " id="middlename" name="middlename" placeholder="Enter Middlename" value="<?php echo e(old('middlename') ?? $person->middlename); ?>">
                                                <?php if($errors->has('middlename')): ?>
                                                <small  class="form-text text-danger"><?php echo e($errors->first('middlename')); ?> </small>
                                                <?php endif; ?>
                                        </div>
    
                                        <div class="form-group col-lg-3">
                                            <label for="lastname">Lastname <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control <?php echo e($errors->has('lastname')  ? 'is-invalid' : ''); ?>" id="lastname" name="lastname" placeholder="Enter Lastname" value="<?php echo e(old('lastname') ?? $person->lastname); ?>">
    
                                            <?php if($errors->has('lastname')): ?>
                                                <small  class="form-text text-danger">
                                                <?php echo e($errors->first('lastname')); ?> </small>
                                            <?php endif; ?>
                                        </div>
    
                                        <div class="form-group col-lg-3">
                                            <label for="suffix">Suffix </label>
                                            <input type="text" class="form-control <?php echo e($errors->has('suffix')  ? 'is-invalid' : ''); ?>" id="suffix" name="suffix" placeholder="e.g Jr." value="<?php echo e(old('suffix') ?? $person->suffix); ?>">
                                            <?php if($errors->has('suffix')): ?>
                                                <small  class="form-text text-danger">
                                                <?php echo e($errors->first('suffix')); ?> </small>
                                            <?php endif; ?>
                                        </div>
                                </div>
    
    
    
    
                                
    
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <label for="date_of_birth">Date of birth <span class="text-danger">*</span></label>
                                            <input type="date" class="form-control  <?php echo e($errors->has('date_of_birth')  ? 'is-invalid' : ''); ?>" id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth') ?? $person->date_of_birth); ?>">
                                            <?php if($errors->has('date_of_birth')): ?>
                                                <small  class="form-text text-danger">
                                                <?php echo e($errors->first('date_of_birth')); ?> </small>
                                            <?php endif; ?>
                                        </div>
    
    
                                    </div>
                                </div>
    
                                
    
    
    
                                <div class="form-group">
                                        <label for="province">Province<span class="text-danger">*</span></label>
                                        <select name="province" id="province" class="form-control <?php echo e($errors->has('province')  ? 'is-invalid' : ''); ?>">
                                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('province')): ?>
                                                        <option <?php echo e(old('province') == $province->code ? 'selected' : ''); ?> value="<?php echo e($province->code); ?>"> <?php echo e($province->name); ?></option>
                                                    <?php else: ?>
                                                        <option <?php echo e($person->province_code == $province->code ? 'selected' : ''); ?> value="<?php echo e($province->code); ?>"> <?php echo e($province->name); ?></option>
                                                    <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('province')): ?>
                                            <small  class="form-text text-danger">
                                            <?php echo e($errors->first('province')); ?> </small>
                                        <?php endif; ?>
                                 </div>
    
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="city">City <span class="text-danger">*</span></label>
                                            <select name="city" id="cities" class="form-control <?php echo e($errors->has('city')  ? 'is-invalid' : ''); ?>">
                                                <option value="" disabled>Select province</option>
                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(old('city')): ?>
                                                        <option <?php echo e(old('city') == $city->code ? 'selected' : ''); ?> value="<?php echo e($city->code); ?>"> <?php echo e($city->name); ?></option>
                                                    <?php else: ?>
                                                        <option <?php echo e($person->city_code == $city->code ? 'selected' : ''); ?>  value="<?php echo e($city->code); ?>"> <?php echo e($city->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('city')): ?>
                                            <small  class="form-text text-danger">
                                            <?php echo e($errors->first('city')); ?> </small>
                                            <?php endif; ?>
                                        </div>
    
                                        <div class="col-lg-6">
                                            <label for="barangay">Barangay<span class="text-danger">*</span></label>
                                            <select name="barangay" id="barangay" class="form-control <?php echo e($errors->has('barangay')  ? 'is-invalid' : ''); ?>">
                                                <option value="" disabled>Select City</option>
                                                <?php $__currentLoopData = $barangays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(old('barangay')): ?>
                                                    <option <?php echo e(old('barangay') == $barangay->code ? 'selected' : ''); ?>  value="<?php echo e($barangay->code); ?>"> <?php echo e($barangay->name); ?></option>
                                                <?php else: ?>
                                                    <option <?php echo e($person->barangay_code == $barangay->code ? 'selected' : ''); ?>   value="<?php echo e($barangay->code); ?>"> <?php echo e($barangay->name); ?></option>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('barangay')): ?>
                                            <small  class="form-text text-danger">
                                            <?php echo e($errors->first('barangay')); ?> </small>
                                            <?php endif; ?>
                                        </div>
                                        </div>
                                    </div>
    

                                    
                                <div class="form-group">
                                        <label for="temporary_address">Temporary Address <span class="text-danger">*</span></label>
                                         <textarea name="temporary_address" id="temporary_address" class="form-control"><?php echo e(old('temporary_address') ?? $person->temporary_address); ?></textarea>
                                    <?php if($errors->has('temporary_address')): ?>
                                         <small  class="form-text text-danger">
                                         <?php echo e($errors->first('temporary_address')); ?> </small>
                                     <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="address">Address <span class="text-danger">*</span></label>
                                    <textarea name="address" id="address" class="form-control <?php echo e($errors->has('address')  ? 'is-invalid' : ''); ?>" rows="3"><?php echo e(old('address') ?? $person->address); ?></textarea>
                                    <?php if($errors->has('address')): ?>
                                        <small  class="form-text text-danger">
                                        <?php echo e($errors->first('address')); ?> </small>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="gender">Sex <span class="text-danger">*</span></label>
                                            <select name="gender" id="gender" class="form-control <?php echo e($errors->has('gender')  ? 'is-invalid' : ''); ?>">
                                                <?php if(old('gender')): ?>
                                                <option <?php echo e(old('gender') == 'male' ? 'selected' : ''); ?> value="male">Male</option>
                                                <option <?php echo e(old('gender') == 'female' ? 'selected' : ''); ?> value="female">Female</option>
                                                    <?php else: ?>
                                                    <option <?php echo e($person->gender == 'male' ? 'selected' : ''); ?> value="male">Male</option>
                                                    <option <?php echo e($person->gender == 'female' ? 'selected' : ''); ?> value="female">Female</option>
                                                <?php endif; ?>
                                                
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="status">Status <span class="text-danger">*</span></label>
                                                <select name="civil_status" id="status" class="form-control <?php echo e($errors->has('civil_status')  ? 'is-invalid' : ''); ?>">
                                                    <?php $__currentLoopData = $civil_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(old('civil_status')): ?>
                                                            <option <?php echo e(old('civil_status') == $status ? 'selected' : ''); ?> value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                                                        <?php else: ?>
                                                        <option <?php echo e($person->civil_status == $status ? 'selected' : ''); ?> value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                                                        <?php endif; ?>
                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <div class="invalid-feedback"><?php echo e($errors->first('civil_status')); ?></div>
                                    </div>
                                    </div>
                                </div>
                                
    
                                
                                
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="email" class="form-control <?php echo e($errors->has('email')  ? 'is-invalid' : ''); ?>" id="email" name="email" placeholder="Optional" value="<?php echo e(old('email')  ?? $person->email); ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="phone_number">Cellphone Number <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control <?php echo e($errors->has('phone_number')  ? 'is-invalid' : ''); ?>" id="phone_number" name="phone_number" placeholder="" value="<?php echo e(old('phone_number') ?? $person->phone_number); ?>">
                                        </div>
                                    </div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label for="landline_number">Landline Number <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control <?php echo e($errors->has('landline_number')  ? 'is-invalid' : ''); ?>" id="landline_number" name="landline_number" placeholder="" value="<?php echo e(old('landline_number') ?? $person->landline_number); ?>">
                                        </div>
                                    </div>
                                </div>
                                
    
                                
    
                                
                                <div class="float-right">
                                    <button type="submit" class="btn btn-success">Update Personnel Information</button>
                                </div>
    
                                <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
            </div>
            <div class="tab-pane fade" id="history" role="tabpanel" aria-labelledby="history-tab">
                <div class="card mt-2">
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <table class="table table-bordered" id="logs-table">
                                <thead>
                                    <tr>
                                        <th>Location</th>
                                        <th>Temperature</th>
                                        <th>Checker</th>
                                        <th>Purpose</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $person->logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($log->location); ?></td>
                                        <td class="text-center"><?php echo e($log->body_temperature); ?></td>
                                        <td class="text-center text-capitalize"><?php echo e($log->checker->lastname); ?>, <?php echo e($log->checker->firstname); ?> <?php echo e($log->checker->middlename); ?></td>
                                        <td><?php echo e($log->purpose); ?></td>
                                        <td class="text-center"><?php echo e($log->time); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
          </div>
      </div>
    </div>
</section>
<?php $__env->startPush('page-scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<script>
    $(document).ready(function () {
        $('#logs-table').DataTable();
    });
</script>
<?php $__env->startPush('page-scripts'); ?>
<script>
    $(document).ready(function () {
        $('#province').change(function (e) {
            $.ajax({
                url : `/api/province/municipal/${e.target.value}`,
                success : function (response) {
                    // Clear all option of cities select element
                    $('#cities').find('option').remove();
                    response.municipals.forEach((municipal) => $('#cities').append(`<option value="${municipal.code}">${municipal.name}</option>`));
                },
            });
        });

        $('#cities').change(function (e) {
            $.ajax({
                url : `/api/province/barangay/${e.target.value}`,
                success : function (response) {
                    // Clear all option of barangay select element
                    $('#barangay').find('option').remove();
                    response.barangays.forEach((barangay) => $('#barangay').append(`<option value="${barangay.code}">${barangay.name}</option>`));
                },
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\capitol_app\resources\views/admin/personnel_logs/show.blade.php ENDPATH**/ ?>