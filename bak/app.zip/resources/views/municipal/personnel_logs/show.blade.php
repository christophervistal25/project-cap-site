@extends('municipal.layouts.app')
@prepend('page-css')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.css">
@endprepend
@section('page-small-title','Personnel')
@section('page-title',  $person->firstname . ' ' . $person->middlename[0] . '. ' . $person->lastname . ' Logs')
@section('content')
<section id="basic-alerts">
  <div class="row match-height">
      <div class="col-xl-4 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">  <img src="{{ asset('/storage/images/' . $person->image) }}" width="10%"> Personnel Information</h4>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                           
                            <div class="form-group">
                                <label for="rapid_pass_no">Rapid Pass No.</label>
                                <input type="text" class="form-control" id="rapid_pass_no" name="rapid_pass_no" placeholder="Rapid Pass No" value="{{ $person->rapid_pass_no }}" readonly>
                            </div>
                    
                    
                            <div class="form-group mt-1">
                            <label for="firstname">Firstname</label>
                            <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Enter Firstname" value="{{ $person->firstname }}" readonly>
                            </div>
                    
                            <div class="form-group">
                                <label for="middlename">Middlename</label>
                                <input type="text" class="form-control " id="middlename" name="middlename" placeholder="Enter Middlename" value="{{ $person->middlename }}" readonly>
                            </div>
                    
                            <div class="form-group">
                                <label for="lastname">Lastname</label>
                                <input type="text" class="form-control" id="lastname" name="lastname" placeholder="Enter Lastname" value="{{ $person->lastname }}" readonly>
                            </div>
                    
                            <div class="form-group">
                                <label for="suffix">Suffix</label>
                                <input type="text" class="form-control" id="suffix" name="suffix" placeholder="e.g Jr." value="{{ $person->suffix }}" readonly>
                            </div>
                    
                        
                    
                            {{-- <hr> --}}
                    
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="date_of_birth">Date of birth</label>
                                        <input type="text" class="form-control " id="date_of_birth" name="date_of_birth" value="{{ $person->date_of_birth }}" readonly>
                                    </div>
                    
                                    <div class="col-lg-6">
                                        <label for="rapid_test_issued">Rapid test issued</label>
                                        <input type="text" class="form-control" id="rapid_test_issued" name="rapid_test_issued"  value="{{ $person->rapid_test_issued }}" readonly>
                                    </div>
                                </div>
                            </div>
                    
                            <div class="form-group">
                                <label for="address">Address</label>
                                <textarea name="address" id="address" class="form-control" rows="3" readonly>{{ $person->address }}</textarea>
                            </div>
                    
                            
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <label for="city">City</label>
                                        <input type="text" class="form-control" id="city" name="city"  value="{{ $person->city->name }}" readonly>
                                    </div>
                                </div>
                            </div>
                    
                            <div class="form-group">
                                <label for="gender">Sex</label>
                                <input type="text" class="form-control" value="{{ ucfirst($person->gender) }}" readonly>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Personnel Logs</h4>
                        <a class="heading-elements-toggle">
                            <i class="la la-ellipsis-v font-medium-3"></i>
                        </a>
                    </div>
                    <div class="card-content collapse show">
                        <div class="card-body">
                            <table class="table table-bordered" id="logs-table">
                                <thead>
                                    <tr>
                                        <th>Location</th>
                                        <th>Temperature</th>
                                        <th>Checker</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($person->logs as $log)
                                    <tr>
                                        <td class="text-center">{{ $log->location }}</td>
                                        <td class="text-center">{{ $log->body_temperature }}</td>
                                        <td class="text-center text-capitalize">{{ $log->checker->lastname }}, {{ $log->checker->firstname }} {{ $log->checker->middlename }}</td>
                                        <td class="text-center">{{ $log->time }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
    </form>
</section>
@push('page-scripts')
<script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<script>
    $('#logs-table').DataTable();
</script>
@endpush
@endsection