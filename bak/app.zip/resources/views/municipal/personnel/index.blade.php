@extends('municipal.layouts.app')
@section('page-small-title','Personnel')
@section('page-title','View Personnel')
@prepend('page-css')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.css">
@endprepend
@section('content')
<div class="card" >
    <div class="card-body">
      <div class="float-right">
        <!--<a href="/municipal/export/options" class="btn btn-primary">EXPORT</a>-->
      </div>
      <div class="clearfix mb-2"></div>
      <table class="table table-bordered table-responsive" id="persons-table" style="width:100%;">
        <thead>
          <tr>
            <td scope="col" class="font-weight-bold">Rapid Pass No.</td>
            <td scope="col" class="font-weight-bold">Firstname</td>
            <td scope="col" class="font-weight-bold">Middlename</td>
            <td scope="col" class="font-weight-bold">Lastname</td>
            <td scope="col" class="font-weight-bold">Suffix</td>
            <td scope="col" class="font-weight-bold">Sex</td>
            <td scope="col" class="font-weight-bold">Birthdate</td>
            <td scope="col" class="font-weight-bold">Rapid Test Date</td>
            <td scope="col" class="font-weight-bold">Permanent Address</td>
            <td scope="col" class="font-weight-bold">Registered Date</td>
            <td scope="col" class="font-weight-bold">Option</td>
          </tr>
        </thead>
        <tbody class="text-center"><tbody>
      </table>
  </div>
</div>
  @push('page-scripts')
  <script>
    $.ajaxSetup({
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
  });
  </script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script>
    // Important INDEX for skipping the OPTION cells in table.
    // If we add or remove some data in table header this variable also need to change.
    // Same with table header at the bottom.
    let INDEX_OF_OPTIONS = 11;

      function cellContentEditableUpdator() {
        let interval = setInterval(() => { 
          console.log('run...');
            if($('tr.even').length !== 0 || $('tr.odd').length !== 0) {
         
              $('tr.odd > td').attr('contenteditable', true);
              $('tr.even > td').attr('contenteditable', true);
              
              $('tr.odd > td').each((index, element)  => {
                if(index % INDEX_OF_OPTIONS == 10) {
                    $(element).attr('contenteditable', false);
                } 
              });

              $('tr.even > td').each((index, element)  => {
                if(index % INDEX_OF_OPTIONS == 10) {
                  $(element).attr('contenteditable', false);
                } 
              });

              clearInterval(interval);
            }
        }, 700);
      }

      cellContentEditableUpdator();

       $(document).on('click', '.paginate_button', function () {
        cellContentEditableUpdator();
       });
  
  </script>
  <script>

    let person_table =  $('#persons-table').DataTable({
            serverSide: true,
            ajax: "{{ route('municipal-people-list') }}",
            columns: [
              { name: 'rapid_pass_no' },
                { name: 'firstname' },
                { name: 'middlename' },
                { name: 'lastname' },
                { name: 'suffix' },
                { name: 'gender' },
                { name: 'date_of_birth' },
                { name: 'rapid_test_issued' },
                { name: 'address' },
                { name: 'created_at' },
                { name: 'action' , searchable : false, orderable : false, },
            ],
        });
  </script>
    <script>
      // This is need for assigning values in JSON Objects.
      // Strictly need to be the same with header in table display.
      let tableHeader = [
        'rapid_pass_no', 'firstname', 'middlename', 'lastname', 'suffix', 'sex', 'birthdate', 'rapid_test_date', 'permanent_address', 'registered_date'
      ];

      $(document).on('click', '.btn-edit-person', function (e) {
        let data = {};

        // Get the id from the clicked button.
        let personId = $(this).attr('data-person-id');

        // Push the id of person in json
        data['person_id'] = personId;

        // get the cells in row iterate to get all the modified values.
        $(`.person-${personId}`).children().each(function(index, element) {
          // Checking if the element is option/action or not.
          if( (INDEX_OF_OPTIONS - 1) !== index ) {
            // Assining the value json
            data[tableHeader[index]] = $(element).text();
          }
        });
       // Ajax request
        $.ajax({
          url : `/municipal/municipal-personnel/${personId}`,
          method : 'PUT',
          data : data,
          success : function (response) {
            swal("Good job!", "Successfully update.", "success");
          },
          error : function(response) {
            if(response.status === 422) {
              // this is a Node object    
              let errorElement = document.createElement("span");

              Object.keys(response.responseJSON.errors).forEach((key) => {
                  errorElement.innerHTML += `<p class='text-danger'>${response.responseJSON.errors[key][0]}</p>`;
              })
                  
              swal({  
                  title: "Opps!", 
                  icon: "error",
                  content: errorElement,
              });
            }
          },
        });

      });
    </script>
  @endpush
@endsection
{{-- @extends('municipal.layouts.app')
@section('page-small-title','Personnel')
@section('page-title','Records')
@prepend('page-css')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.css">
@endprepend
@section('content')

 <!-- Dropdown Card Example -->
 <div class="card  mb-3 d-none" id="dynamic__logs__view">
  <!-- Card Header - Dropdown -->
  <div
      class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-primary" id="dynamic__log__title">Record</h6>
      <div class="">
          <button id="remove__dynamic__logs__view" class="btn btn-danger btn-sm">
              <i class="fas fa-times text-white"></i>
          </button>
      </div>
  </div>
  <!-- Card Body -->
    <div class="card-body" id="dynamic__logs__content">
      <table class="table table-bordered" id="persons-log-table" style="width:100%;">
        <thead>
          <tr>
            <td scope="col" class="font-weight-bold">Location</td>
            <td scope="col" class="font-weight-bold">Body Temperature</td>
            <td scope="col" class="font-weight-bold">Date and Time</td>
          </tr>
        </thead>
        <tbody id="person__logs__data"><tbody>
      </table>
    </div>
  </div>


<div class="card ">
    <div class="card-body">
      <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <li class="nav-item">
          <a class="nav-link " id="pills-records-tab" data-toggle="pill" href="#pills-records" role="tab" aria-controls="pills-records" aria-selected="true">Records</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" id="pills-add-personnel-tab" data-toggle="pill" href="#pills-add-personnel" role="tab" aria-controls="pills-add-personnel" aria-selected="false">Add Record</a>
        </li>
        

      </ul>

      <hr>

      <div class="tab-content " id="pills-tabContent">
        <div class="tab-pane  fade " id="pills-records" role="tabpanel" aria-labelledby="pills-records-tab">
            @include('municipal.personnel.records')
        </div>

        <div class="tab-pane fade" id="pills-add-personnel" role="tabpanel" aria-labelledby="pills-add-personnel-tab">
            @include('municipal.personnel.create')
        </div>

      </div>
    </div>
  </div>

  @push('page-scripts')
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script>
    (function() {
      let previousSelectedTab = localStorage.getItem('selected_tab'); 
      
      // If no selected table dispaly default which is "Records"
      if(!previousSelectedTab) {
        previousSelectedTab = 'pills-records-tab';
      }

      // Active the tab.
      $(`#${previousSelectedTab}`).addClass('active');

      // Display the UI.
      $(`#${previousSelectedTab.replace('-tab', '')}`).addClass('active').addClass('show');

    })();
    $('#pills-tab a').on('click', function (e) {
      e.preventDefault()
      //Selected tab 
      let tabId = $(this).attr('id');
      localStorage.setItem('selected_tab', tabId);
      $(this).tab('show')
      $('#edit__person__form').addClass('d-none');
      $('#edit__person__warning__message').removeClass('d-none');
    })
  </script>

  <script>
      $('#persons-table').DataTable({
            serverSide: true,
            ajax: "{{ route('municipal-people-list') }}",
            columns: [
                { name: 'firstname' },
                { name: 'middlename' },
                { name: 'lastname' },
                { name: 'suffix' },
                { name: 'date_of_birth' },
                { name: 'rapid_test_issued' },
                { name: 'created_at' },
                { name: 'action', orderable: false, searchable: false }
                
            ],
        });
  </script>
  
  <script>
    // LOGS SCRIPTS
    $(document).on('click', '.btnViewPersonLogs', function (e) {
      let personId = $(this).attr('data-person-id');
      let logElement = $('#person__logs__data')

      $('#dynamic__logs__view').removeClass('d-none');
      $('#person__logs__data').html('');

        // Fetch record
      $.ajax({
        url : `/municipal/person/${personId}/logs`,
        success : (response) => {
            $('#dynamic__log__title').html(`<h6 class="m-0 font-weight-bold text-primary">${response.lastname} , ${response.firstname} ${response.middlename} ${response.suffix ? response.suffix : '' } <span class="font-weight-normal">Logs</span></h6>`);
            response.logs.forEach((log) => {
              $('#person__logs__data').append(
                `<tr>
                  <td>${log.location}</td>
                  <td>${log.body_temperature}</td>
                  <td>${log.time}</td>
                </tr>
                `)
            })
        },
        
      });
    });

    $('#remove__dynamic__logs__view').click(function(e) {
      $('#dynamic__logs__view').addClass('d-none');
    })
  </script>
  @endpush
@endsection --}}
