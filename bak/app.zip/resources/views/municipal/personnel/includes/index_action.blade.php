<div class="text-center">
    <button title="View logs of {{ $person->firstname }}" class="btn btn-sm btn-success btn-icon btn-edit-person" data-person-id="{{ $person->id }}"><i class="la la-check"></i></button>
    <a href="{{ route('municipal.personnel.logs', $person->id) }}" target="_blank" title="View Generated QR Code" class=" text-sm btn btn-sm btn-info  btn-icon btn-info hide_btna" style="color:white;"> <i class="la la-history"></i></a>

{{-- <button class="btn btn-danger btn-icon  btn-sm"><i class="la la-trash"></i></button> --}}
<a class="btn btn-success btn-icon  btn-sm" href="{{ route('municipal.print.qr', $person->id) }}" target="_blank"><i class="la la-print"></i></a>
</div>
{{-- <a target="_blank" title="View Generated QR Code" class="btn btn-sm btn-icon btn-success" href="{{ asset('/storage/qr_images/' . $person->generated_qr) }}"> <i class="la la-check"></i></a>
<a href="{{ route('municipal-personnel.edit', $person->id) }}" title="Edit {{ $person->firstname }} information" class="btn btn-sm btn-success btnEditPerson"><i class="la la-pen"></i></a>
<button  title="View logs of {{ $person->firstname }}" class="btn btn-sm btn-info btnViewPersonLogs" data-person-id="{{ $person->id }}"><i class="la la-tasks"></i></button> --}}
