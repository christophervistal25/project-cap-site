@include('templates.header')
        @yield('content')
@include('templates.footer')
