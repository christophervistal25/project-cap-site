@extends('admin.layouts.app')
@section('page-small-title','Personnel')
@section('page-title','View Personnel')
@prepend('page-css')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.css">
@endprepend
@section('content')
<div class="card" >
    <div class="card-body">
      <div class="row float-left col-lg-7">
        <div class="col-lg-7">
          <select name="cities" id="city_filter" class="form-control">
            <option value="all">Show All</option>
            @foreach($cities as $city)
              <option value="{{ $city->zip_code }}"> {{ $city->name }}</option>
            @endforeach
          </select>
        </div>

        
      </div>
      {{-- <div class="float-right">
        <a href="/admin/export/options" class="btn btn-primary">EXPORT</a>
      </div> --}}
      <div class="clearfix mb-2"></div>
      <table class="table table-bordered " id="persons-table" style="width:100%;">
        <thead>
          <tr>
            <td scope="col" class="font-weight-bold">Rapid Pass No.</td>
            <td scope="col" class="font-weight-bold">Firstname</td>
            <td scope="col" class="font-weight-bold">Middlename</td>
            <td scope="col" class="font-weight-bold">Lastname</td>
            <td scope="col" class="font-weight-bold">Suffix</td>
            <td scope="col" class="font-weight-bold">Sex</td>
            <td scope="col" class="font-weight-bold">Birthdate</td>
            <td scope="col" class="font-weight-bold">Rapid Test Date</td>
            <td scope="col" class="font-weight-bold">Permanent Address</td>
            <td scope="col" class="font-weight-bold">Registered Date</td>
            <td scope="col" class="font-weight-bold">Option</td>
          </tr>
        </thead>
        <tbody>
        </tbody>
      </table>
  </div>
</div>
  @push('page-scripts')
  <script>
    $.ajaxSetup({
    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
  });
  </script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/startbootstrap-sb-admin-2@4.1.3/vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script>
    // Important INDEX for skipping the OPTION cells in table.
    // If we add or remove some data in table header this variable also need to change.
    // Same with table header at the bottom.
    let INDEX_OF_OPTIONS = 11;

      function cellContentEditableUpdator() {
        let interval = setInterval(() => { 
          console.log('run...');
            if($('tr.even').length !== 0 || $('tr.odd').length !== 0) {
         
              $('tr.odd > td').attr('contenteditable', true);
              $('tr.even > td').attr('contenteditable', true);
              
              $('tr.odd > td').each((index, element)  => {
                if(index % INDEX_OF_OPTIONS == 10) {
                    $(element).attr('contenteditable', false);
                } 
              });

              $('tr.even > td').each((index, element)  => {
                if(index % INDEX_OF_OPTIONS == 10) {
                  $(element).attr('contenteditable', false);
                } 
              });

              clearInterval(interval);
            }
        }, 700);
      }

      cellContentEditableUpdator();

       $(document).on('click', '.paginate_button', function () {
        cellContentEditableUpdator();
       });
  
  </script>
  <script>
    let QUERY_STRING = 'all';

    if(localStorage.getItem('FILTER_SELECT') == null) {
      QUERY_STRING = 'all';
    } else {
      QUERY_STRING = localStorage.getItem('FILTER_SELECT');
      $('#city_filter').val(QUERY_STRING);
    }

    let person_table =  $('#persons-table').DataTable({
            serverSide: true,
            ajax: `/admin/persons/list/${QUERY_STRING}`,
            columns: [
                { name: 'rapid_pass_no' },
                { name: 'firstname' },
                { name: 'middlename' },
                { name: 'lastname' },
                { name: 'suffix' },
                { name: 'gender' },
                { name: 'date_of_birth' },
                { name: 'rapid_test_issued' },
                { name: 'address' },
                { name: 'created_at' },
                { name: 'admin_action' , searchable : false, orderable : false, },
                // { name: 'role.name', orderable: false },
                // { name: 'action', orderable: false, searchable: false }
            ],
        });
  </script>
  
   <script>
      $('#city_filter').change(function (e) {
          QUERY_STRING = $(this).val();
          localStorage.setItem('FILTER_SELECT', QUERY_STRING);
          person_table.ajax.url(`/admin/persons/list/${QUERY_STRING}`).load();
          cellContentEditableUpdator();
      });
    </script>

    <script>
      // This is need for assigning values in JSON Objects.
      // Strictly need to be the same with header in table display.
      let tableHeader = [
        'rapid_pass_no', 'firstname', 'middlename', 'lastname', 'suffix', 'sex', 'birthdate', 'rapid_test_date', 'permanent_address', 'registered_date'
      ];

      $(document).on('click', '.btn-edit-person', function (e) {
        let data = {};

        // Get the id from the clicked button.
        let personId = $(this).attr('data-person-id');

        // Push the id of person in json
        data['person_id'] = personId;

        // get the cells in row iterate to get all the modified values.
        $(`.person-${personId}`).children().each(function(index, element) {
          // Checking if the element is option/action or not.
          if( (INDEX_OF_OPTIONS - 1) !== index ) {
            // Assining the value json
            data[tableHeader[index]] = $(element).text();
          }
        });
        // Ajax request
        $.ajax({
          url : `/admin/personnel/${personId}`,
          method : 'PUT',
          data : data,
          success : function (response) {
            swal("Good job!", "Successfully update.", "success");
          },
          error : function(response) {
            if(response.status === 422) {
              // this is a Node object    
              let errorElement = document.createElement("span");

              Object.keys(response.responseJSON.errors).forEach((key) => {
                  errorElement.innerHTML += `<p class='text-danger'>${response.responseJSON.errors[key][0]}</p>`;
              })
                  
              swal({  
                  title: "Opps!", 
                  icon: "error",
                  content: errorElement,
              });
            }
          },
        });

      });
    </script>
  @endpush
@endsection