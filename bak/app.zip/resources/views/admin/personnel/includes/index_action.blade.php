<div class="text-center">
    <button title="View logs of {{ $person->firstname }}" class="mb-1 btn btn-sm btn-success btn-icon btn-edit-person" data-person-id="{{ $person->id }}"><i class="la la-check"></i></button>
    <a href="{{ route('personnel.logs', $person->id) }}" target="_blank" title="View Generated QR Code" class="mb-1 text-sm btn btn-sm btn-info  btn-icon btn-info hide_btna" style="color:white;"> <i class="la la-history"></i></a>

{{-- <button class="btn btn-danger btn-icon  btn-sm"><i class="la la-trash"></i></button> --}}
<a class="btn btn-success btn-icon  btn-sm" href="{{ route('admin.print.qr', $person->id) }}" target="_blank"><i class="la la-print"></i></a>
</div>