<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Person;

class PersonnelLogController extends Controller
{
    /** 
     * @id Person ID
     */
    public function show($id)
    {
        $person = Person::with('logs')->find($id);
        return view('admin.personnel_logs.show', compact('person'));
    }
}
