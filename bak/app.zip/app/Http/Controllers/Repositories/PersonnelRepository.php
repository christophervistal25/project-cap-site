<?php

namespace App\Http\Controllers\Repositories;
use App\Person;
use App\Barangay;
use App\Http\Controllers\Repositories\Encrytor;

class PersonnelRepository 
{
    public const QR_SEPERATOR = '|';
    public const GENDER = ['Male', 'Female'];

    public static function generateQR(Person $person)
    {
        $renderer = new ImageRenderer(
            new RendererStyle(400),
            new ImagickImageBackEnd()
        );
        
        $QR_NAME = time() . '_' . md5(time() . '_' . $person->firstname) . '_qr.png';

        $QR_CODE_PATH = storage_path('/app/public/qr_images/' . $QR_NAME);
        
        $writer = new Writer($renderer);
        $data = $writer->writeFile(self::generateQRbyData($person), $QR_CODE_PATH);

        return $QR_NAME;
    }

    public static function generateQRbyData(Person $person)
    {
        $user_information =   $person->id . self::QR_SEPERATOR . $person->firstname . self::QR_SEPERATOR . $person->middlename . self::QR_SEPERATOR . $person->lastname 
        . self::QR_SEPERATOR . $person->suffix . self::QR_SEPERATOR . $person->address . self::QR_SEPERATOR .   $person->date_of_birth . self::QR_SEPERATOR . $person->rapid_test_issued;
        return Encryptor::process($user_information);
    }
}
