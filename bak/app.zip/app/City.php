<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    public    $incrementing = false;
    protected $primaryKey   = 'zip_code';
    protected $fillable     = ['zip_code', 'name', 'status'];

    public function barangays()
    {
        return $this->hasMany('App\Barangay');
    }
    
    public function people()
    {
        return $this->hasMany('App\Person');
    }
}
