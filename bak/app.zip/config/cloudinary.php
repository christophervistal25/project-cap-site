<?php


return [
    'CLOUD_NAME' => 'dhoso0sdj',
    'API_KEY' => '384471477377866',
    'API_SECRET' => 'xYLeK2tYxXO13g8N7Iei7WlHiaw',
];
